var express = require("express");
var app = express();
app.listen(3001, () => {
 console.log("Server running on port 3001");
});

app.get("/employees", (req, res, next) => {
    insertRecord();
    res.json(["Tony","Lisa","Michael","Ginger","Food"]);
});

app.get("/delete", (req, res, next) => {
    deleteRec();
    res.json({"status":"succes"});
});

var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/";

MongoClient.connect(url, function(err, db) {
  if (err) throw err;
  var dbo = db.db("test");
  dbo.collection("name").findOne({}, function(err, result) {
    if (err) throw err;
    console.log(result.age);
    db.close();
  });
});

var insertRecord = function() {
    MongoClient.connect(url, function(err, db) {
        if (err) throw err;
        var dbo = db.db("test");
        var myobj = { name: "Company Inc", address: "Highway 37" };
        dbo.collection("name").insertOne(myobj, function(err, res) {
          if (err) throw err;
          console.log("1 document inserted");
          db.close();
        });
      });
};

var deleteRec = function() {
    MongoClient.connect(url, function(err, db) {
        if (err) throw err;
        var dbo = db.db("test");
        var myquery = { name: 'Company Inc' };
        dbo.collection("name").deleteOne(myquery, function(err, obj) {
          if (err) throw err;
          console.log("1 document deleted");
          db.close();
        });
      });
}