module.exports = {
  plugins: {
    'autoprefixer': {},
    'cssnano': {},
    'postcss-cssnext': {}
  }
}