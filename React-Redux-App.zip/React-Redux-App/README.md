# react-redux-router-saga-material-postcss-webpack
Basic setup for in title mentioned libs

https://itnext.io/fast-and-modern-front-end-setup-with-webpack-react-redux-router-saga-and-postcss-1360e9715d17
