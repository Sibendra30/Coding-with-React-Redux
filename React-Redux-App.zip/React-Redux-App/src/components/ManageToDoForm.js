import React from 'react';
import ToDoItemView from './ToDoItemView';

export default function ManageToDoForm({todoList}) {
    return (
        <div>   
            <h1>Manage Todo Items</h1>
            {
                todoList && todoList.map((item) => <ToDoItemView item={item}/>)
            }
        </div>
    );
}
