import React from "react";
import PropTypes from 'prop-types';
import AddToDoForm from './AddToDoForm';
import ManageToDoForm from './ManageToDoForm';

class App extends React.Component {

	constructor(props) {
		super(props);
		this.onTabClick = this.onTabClick.bind(this);
		this.addToDoItemHandler = this.addToDoItemHandler.bind(this);
	}
	componentWillMount() {
		this.props.onCreate();
	}

	addToDoItemHandler(item) {
		console.log('Adding item into list...');
		const curState = this.state || {};
		const {todoList = [], showAddTodoForm, showManageTodoForm} = curState;
		todoList.push(item);
		this.setState(...curState, todoList, showAddTodoForm: false, showManageTodoForm: false);
	}

	onTabClick(event) {
		const eventType = event.target.getAttribute('id');
		const curState = this.state || {};
		if (eventType === 'addTodo') {
			this.setState({...curState, showAddTodoForm: true, showManageTodoForm: false});
		} else {
			this.setState({...curState, showManageTodoForm: true, showAddTodoForm: false});
		}
	}

 	render() {
		const curState = this.state || {};
		const {showAddTodoForm, showManageTodoForm, todoList} = curState;
    	return <div>
    		<ul class="nav">
  				<li class="nav-item">
    				<a class="nav-link active" href="#" id="addTodo" onClick={this.onTabClick}>Add ToDo</a>
  				</li>
  				<li class="nav-item">
    				<a class="nav-link active" id="manageTodo" href="#" onClick={this.onTabClick}>Manage Todo</a>
  				</li>				  
			</ul>
			{this.props.children}
			{showAddTodoForm ? <AddToDoForm addToDoItemHandler={this.addToDoItemHandler}/> : null}
			{showManageTodoForm ? <ManageToDoForm todoList={todoList}/> : null}
    	</div>
  	}

}

App.propTypes = {
	onCreate: PropTypes.func.isRequired,
	location: PropTypes.string
}

App.defaultProps = {

}

export default App;