import React from 'react';

export default function ToDoItemView({item}) {
    return (
        <div>  
            ToDo
        </div>
    );
}
