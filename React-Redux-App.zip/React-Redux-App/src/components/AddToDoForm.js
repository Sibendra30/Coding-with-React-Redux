import React from 'react';

export default class AddToDoForm extends React.Component {
    constructor(props) {
        super(props);
        this.onAddBtnClick = this.onAddBtnClick.bind(this);
        this.onTextChange = this.onTextChange.bind(this);
    }

    onAddBtnClick() {
        const {addToDoItemHandler} = this.props;
        const curState = this.state;
        const {name, desc} = curState;
        const item = {name, desc};
        addToDoItemHandler(item);
    }
    onTextChange(event) {
        const curState = this.state || {};
        const eventType = event.target.getAttribute('id');
        const value = event.target.value;
        let newState = curState;
        if (eventType === 'name') {
            newState = {...newState, name:value}
        }
        if (eventType === 'desc') {
            newState = {...newState, desc:value}
        }
        newState = {...curState, ...newState};
        this.setState(newState);
    }

    componentWillUpdate(nextProps, nextState) {
        console.log(nextProps);
        console.log(nextState);
    }

    render() {
        
        const {name = '', desc = ''} = this.state || {};
        return (
            <div>   
                <h1>Add Todo Item</h1>
                <label htmlFor="name">Item Name</label>
                <input type="text" class="form-control" value={name}
                   onChange={this.onTextChange} id="name" placeholder="Enter item name" />
                <label htmlFor="desc">Item Description</label>
                <input type="text" class="form-control" value={desc}
                    onChange={this.onTextChange} id="desc" placeholder="Enter item description" />
                <button type="submit" onClick={this.onAddBtnClick} class="btn btn-primary">Add</button>
            </div>
        );
    }
}
