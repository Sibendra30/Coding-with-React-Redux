import React, {Component} from 'react';
import { connect } from 'react-redux'

class SampleAppComponent extends Component {
    constructor() {
        super();
        this.handleClick = this.handleClick.bind(this);
    }
    handleClick() {
        console.log(this.props);
        this.props.saveData();
    }
    render() {
        console.log(this.props);
        return(
            <div>
                <p>Sample App View </p>
                <button onClick={this.handleClick}>Click Me Please</button>
            </div>
        );
    }
}

const mapStateToProps = state => {
    return {
        data: state || {}
    }
}

const mapDispatchToProps = dispatch => {
    return {
        saveData: () =>
            dispatch({
                type: 'SAVE_DATA', payload: {isDataSaved: true}
            })
    }
}

export default connect(
    mapStateToProps,
    mapDispatchToProps
)(SampleAppComponent);