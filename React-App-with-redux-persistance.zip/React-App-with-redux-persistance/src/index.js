import React from 'react';
import ReactDOM from 'react-dom';
import SampleAppComponent from './SampleApp.component';
import { Provider } from 'react-redux';
import store, {persistor} from './store';
import { PersistGate } from 'redux-persist/lib/integration/react';

const title = 'My Minimal React Webpack Babel Setup';

ReactDOM.render(
  <Provider store={store}><PersistGate persistor={persistor}><SampleAppComponent /></PersistGate></Provider>,
  document.getElementById('app')
);

module.hot.accept();