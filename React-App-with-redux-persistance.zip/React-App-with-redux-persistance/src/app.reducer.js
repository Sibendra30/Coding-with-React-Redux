export default function (state = {}, action) {
    let newState = {};
    switch(action.type) {
        case "SAVE_DATA":
            newState = {...state, isDataSaved: true};
            break;
        default:
            newState = state;
    }

    return newState;
}