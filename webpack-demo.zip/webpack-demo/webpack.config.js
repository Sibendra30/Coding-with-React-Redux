const path = require('path');
module.exports = {
    entry: ["./lib/app.js"],
    output: {
        filename: "webpack-demo.js"
    },
    watch: true,
    mode: "production",
    resolve: {
        extensions: ['.js', '.jsx']
    },
    module: {
        rules: [
            {
                test: /\.jsx?$/,
                loader: 'babel-loader',
                exclude: /node_modules/,
                options: {
                    presets: ['react', 'es2015','stage-2']
                }
            }
        ]
    }
}