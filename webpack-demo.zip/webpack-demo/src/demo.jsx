import React from 'react';
import { connect } from 'react-redux'

export const CONST_VALUE = 'I am Mr. Const';
class DemoClass extends React.Component {
    constructor(props) {
        super(props);
        console.log('Demo class loaded successfully');
    }
    render() {
        console.dir(this.props);
        console.log('Demo class loaded successfully');
        return (
            <div>
                <span>Welcome to Github World   !!!</span>
                <button onClick={this.props.destroyTodo}>Don't Click Me</button>
            </div>
        );
    }
}

const mapStateToProps = state => {
    return {
        todo: state && state.todos ? state.todos[0] : {}
    }
}

const mapDispatchToProps = dispatch => {
    return {
        destroyTodo: () =>
            dispatch({
                type: 'DESTROY_TODO'
            })
    }
}

export default connect(
    mapStateToProps,
    mapDispatchToProps
)(DemoClass);