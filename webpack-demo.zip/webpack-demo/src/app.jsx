import React from "react";
import ReactDOM from "react-dom";
import Hello from "./demo";
import { Provider } from 'react-redux';
import store from './reducer';

ReactDOM.render(
    <Provider store={store}>
        <Hello name="World" />
    </Provider>,
    document.getElementById('root')
);