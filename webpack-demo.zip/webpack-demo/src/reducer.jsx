import {createStore} from 'redux';
import combinedReducer from './combinedReducer';
const initialState = {};

export default createStore(combinedReducer);
