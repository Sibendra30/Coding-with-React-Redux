export default function (state = {}, action) {
    let newState = {};
    switch(action.type) {
        case "LOGIN":
            newState = {...state, auth: 'success'};
            break;
        case "DESTROY_TODO":
            const todos = [{
                text: 'Get Up Early',
                completed: false
            }, {
                text: 'Go to Gym',
                completed: false
            }];
            newState = {...state, todos};
            break;
        default:
            newState = state;
    }

    return newState;
}